# 🍳 Ide Masakan & Cemilan Ringan

Ini adalah website sederhana yang dibuat menggunakan **HTML, CSS, dan JavaScript**. Website ini menyediakan berbagai inspirasi cemilan ringan yang mudah dibuat di rumah.

## 🌟 Fitur
- Menampilkan daftar ide cemilan beserta deskripsi singkatnya.
- Dilengkapi dengan fitur **"Pilih Acak Untukku!"** untuk membantu menentukan pilihan saat bingung ingin membuat apa.
- Desain responsif yang rapi baik di komputer maupun di handphone.

## 🚀 Teknologi yang Digunakan
- **HTML5** untuk struktur halaman.
- **CSS3** untuk desain, tata letak (Grid), dan warna.
- **JavaScript (Vanilla)** untuk memuat daftar cemilan secara dinamis dan logika pemilihan acak.

## 🌐 Cara Menjalankan Project
Kamu bisa melihat project ini secara langsung karena telah di-deploy menggunakan **GitHub Pages**.

Jika ingin menjalankan secara lokal:
1. Clone repository ini:
   ```bash
   git clone https://github.com/username-kamu/nama-repository.git
   ```
2. Buka folder project.
3. Klik ganda pada file `index.html` untuk membukanya di browser.

## 👨‍💻 Kontribusi
Dibuat oleh [Nama Kamu]. Jangan ragu untuk _fork_ dan menambahkan ide resep cemilan lainnya!