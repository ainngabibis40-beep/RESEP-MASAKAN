// Daftar ide cemilan
const snacks = [
    { name: "Tahu Walik", desc: "Tahu goreng renyah dengan isian adonan ayam dan tepung tapioka." },
    { name: "Pisang Goreng Keju", desc: "Pisang manis berbalut tepung renyah dengan taburan keju dan susu kental manis." },
    { name: "Seblak Mercon", desc: "Kerupuk basah pedas dengan tambahan sosis, telur, dan ceker ayam." },
    { name: "Martabak Manis Mini", desc: "Martabak ukuran kecil dengan topping meses, kacang, atau keju." },
    { name: "Cilok Bumbu Kacang", desc: "Aci dicolok kenyal dengan siraman bumbu kacang yang gurih pedas." },
    { name: "Dimsum Ayam", desc: "Siomay ayam kukus yang lembut, disajikan dengan saus sambal." },
    { name: "Jasuke (Jagung Susu Keju)", desc: "Jagung manis rebus yang dicampur margarin, susu, dan keju parut." },
    { name: "Makaroni Ngehe", desc: "Makaroni goreng renyah dengan taburan bumbu pedas dan asin." }
];

const recipeList = document.getElementById('recipe-list');
const randomBtn = document.getElementById('randomBtn');
const randomResult = document.getElementById('randomResult');

// Fungsi untuk menampilkan daftar cemilan ke HTML
function displaySnacks() {
    snacks.forEach(snack => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <h3>${snack.name}</h3>
            <p>${snack.desc}</p>
        `;
        recipeList.appendChild(card);
    });
}

// Fungsi untuk memilih cemilan acak
randomBtn.addEventListener('click', () => {
    const randomIndex = Math.floor(Math.random() * snacks.length);
    const chosenSnack = snacks[randomIndex];
    randomResult.innerHTML = `💡 Coba bikin: <strong>${chosenSnack.name}</strong>!`;
});

// Jalankan fungsi saat halaman dimuat
displaySnacks();